Welcome to the WikiLinkConvertor wiki!

test wrong format
- link to not a file [wrong file](nope.md)
- link to not a page [wrong page](https://github.com/alterGNU/WikiLinkConvertor/wiki/nope)

- link to a real file [toto.titi.tutu.md](https://github.com/alterGNU/WikiLinkConvertor/wiki/toto.titi.tutu)
- link to a webpage [webpage](www.google.com)
- link to a another [first secure](https://www.google.com) link to a anothet another [seconde not secure](http://www.google.com)


- insert image link without description ![](wlc.jpg)
- insert image link with description ![wlc](wlc.jpg)
- insert image link without description ![](wlc.jpg) and in same line ![wlc](wlc.jpg)
- insert image link without description ![wlc](wlc.jpg) and in same line ![](wlc.jpg)
- insert image link without description ![wlc](wlc.jpg) and in same line ![wlc](wlc.jpg)
