# load_anim functions

## TOC
- [Exemples](#exemples)
    - [f0()](#f0)
    - [f1(toto)](#f1toto)
    - [f2(titi)](#f2titi)
    - [f3(tutu)](#f3tutu)
- [Sources](#sources)

--- 
## Exemples

### f0()
- **Usage**: 
- **Args** : 
    - arg1 : 
    - arg2 : 
- **Exemples** : 
    ```bash
    ...
    ...
    ...
    ```
[🆙](#page-title)

--- 

### f1(toto)
- **Usage**: 
- **Args** : 
    - arg1 : 
    - arg2 : 
- **Exemples** : 
    ```bash
    ...
    ...
    ...
    ```
[🆙](#page-title)

--- 

### f2()
- **Usage**: 
- **Args** : 
    - arg1 : 
    - arg2 : 
- **Exemples** : 
    ```bash
    ...
    ...
    ...
    ```
[🆙](#page-title)

--- 

### f3()
- **Usage**: 
- **Args** : 
    - arg1 : 
    - arg2 : 
- **Exemples** : 
    ```bash
    ...
    ...
    ...
    ```
[🆙](#page-title)

--- 

## Sources
- [source 1](https://www.trustmebro.com)
- [source 2](https://www.gogole.fr)

[🆙](#page-title)

[🏠 Home](https://github.com/alterGNU/WikiLinkConvertor/wiki/home)
